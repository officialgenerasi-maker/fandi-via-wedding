// script.js - interaksi undangan (komentar inline agar mudah diedit di HP)

/* Helper: pilih elemen sekali, aman untuk HP editors */
const $ = id => document.getElementById(id);

/* COVER OPEN: sembunyikan cover dan coba mainkan audio.
   Catatan: autoplay bisa diblokir oleh beberapa browser mobile,
   tapi setelah pengguna menekan 'Buka Undangan' audio biasanya boleh diputar. */
document.getElementById('openBtn').addEventListener('click', () => {
  document.getElementById('cover').style.display = 'none';
  const a = document.getElementById('audio');
  if(a){
    a.play().catch(()=>{ /* jika browser blok autoplay, diterima */ });
    document.getElementById('musicBtn').textContent = '🔊';
  }
});

/* MUSIC TOGGLE: tombol untuk menyalakan/mematikan musik */
document.getElementById('musicBtn').addEventListener('click', () => {
  const a = document.getElementById('audio');
  if(!a) return;
  if(a.paused){ a.play(); document.getElementById('musicBtn').textContent='🔊'; }
  else { a.pause(); document.getElementById('musicBtn').textContent='🔈'; }
});

/* COUNTDOWN: Dua tanggal berbeda (akad & resepsi) */
function startCountdown(id, targetISO){
  const el = document.getElementById(id);
  function update(){
    const now = new Date();
    const target = new Date(targetISO);
    let diff = target - now;
    if(diff < 0){ el.textContent = 'Telah berlangsung'; return; }
    const days = Math.floor(diff/86400000); diff%=86400000;
    const hours = Math.floor(diff/3600000); diff%=3600000;
    const mins = Math.floor(diff/60000); diff%=60000;
    const secs = Math.floor(diff/1000);
    el.textContent = `${days} Hari ${hours} Jam ${mins} Menit ${secs} Detik`;
  }
  update(); setInterval(update,1000);
}
startCountdown('countdown1', '2025-12-21T08:00:00+07:00');
startCountdown('countdown2', '2025-12-28T09:00:00+07:00');

/* RSVP: simpan ke localStorage supaya pemilik mudah lihat daftar tamu dari browser */
document.getElementById('rsvp-submit').addEventListener('click', () => {
  const name = document.getElementById('rsvp-name').value.trim();
  const count = document.getElementById('rsvp-count').value || '1';
  if(!name){ alert('Masukkan nama'); return; }
  const key = 'rsvp_fandi_via';
  const list = JSON.parse(localStorage.getItem(key) || '[]');
  list.push({name, count, ts: Date.now()});
  localStorage.setItem(key, JSON.stringify(list));
  renderRSVP();
  document.getElementById('rsvp-name').value=''; document.getElementById('rsvp-count').value='';
  alert('Terima kasih, RSVP tersimpan');
});
function renderRSVP(){
  const key='rsvp_fandi_via';
  const list = JSON.parse(localStorage.getItem(key) || '[]');
  const el = document.getElementById('rsvp-list');
  el.innerHTML = list.map(i => `<div class="item"><strong>${escapeHtml(i.name)}</strong> — ${escapeHtml(i.count)}</div>`).join('');
}
renderRSVP();

/* AMBILOP: salin nomor rekening ke clipboard (fallback ke prompt bila clipboard tidak tersedia) */
document.getElementById('copyBank').addEventListener('click', async () => {
  const text = '5310880649 a/n ALFANDI SULAEMAN';
  try{
    await navigator.clipboard.writeText(text);
    alert('Nomor rekening tersalin');
  }catch(e){
    prompt('Salin nomor rekening di bawah:', text);
  }
});

/* UCAPAN: simpan ke localStorage agar tampil di halaman */
document.getElementById('wish-send').addEventListener('click', () => {
  const name = document.getElementById('wish-name').value.trim() || 'Tamu';
  const text = document.getElementById('wish-text').value.trim();
  if(!text){ alert('Tulis ucapan Anda'); return; }
  const key = 'wishes_fandi_via';
  const list = JSON.parse(localStorage.getItem(key) || '[]');
  list.unshift({name, text, ts: Date.now()});
  localStorage.setItem(key, JSON.stringify(list));
  document.getElementById('wish-name').value=''; document.getElementById('wish-text').value='';
  renderWishes();
  alert('Ucapan terkirim — terima kasih');
});
function renderWishes(){
  const key='wishes_fandi_via';
  const list = JSON.parse(localStorage.getItem(key) || '[]');
  const el = document.getElementById('wishes');
  el.innerHTML = list.map(i => `<div class="item"><strong>${escapeHtml(i.name)}</strong><div>${escapeHtml(i.text)}</div></div>`).join('');
}
renderWishes();

/* escapeHtml sederhana untuk keamanan tampilan */
function escapeHtml(s){ return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
