Undangan Alfandi & Via - Paket Netlify siap upload
-------------------------------------------------
Isi folder:
- index.html
- style.css
- script.js
- assets/
    - foto1.jpg ... foto10.jpg   (prewedding photos)
    - musik.mp3                  (NOT INCLUDED - add your instrumental mp3 here)
- netlify.toml

Cara pakai:
1. (Optional) Ganti assets/foto*.jpg jika mau update (nama harus tetap sama).
2. Tambahkan file musik instrumental bernama 'musik.mp3' ke folder assets/ jika mau autoplay.
   Saya menggunakan: "Can’t Help Falling in Love – Instrumental" (pastikan Anda punya izin/versi instrumental).
3. Zip seluruh folder 'undangan_fandi_via' lalu upload ke Netlify Drop (https://app.netlify.com/drop).
4. Jika ingin edit teks kecil, buka index.html di editor (Acode / Kodex) lalu simpan.

Catatan:
- Musik autoplay bisa diblokir oleh beberapa browser seluler; tamu bisa tekan tombol Play jika perlu.
- Semua kode sudah berkomentar inline untuk memudahkan edit di HP.
